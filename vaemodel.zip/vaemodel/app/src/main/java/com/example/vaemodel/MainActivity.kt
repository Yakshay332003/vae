package com.example.vaemodel

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import org.tensorflow.lite.DataType
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

class MainActivity : AppCompatActivity() {
    private lateinit var interpreter: Interpreter
    private val THRESHOLD = 250f // Adjust this threshold as needed

    // Define EditText variables for each input
    private lateinit var editText1: EditText
    private lateinit var editText2: EditText
    private lateinit var editText3: EditText
    private lateinit var editText4: EditText
    private lateinit var editText5: EditText
    private lateinit var editText6: EditText
    private lateinit var editText7: EditText
    private lateinit var editText8: EditText
    private lateinit var editText9: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize TensorFlow Lite interpreter
        interpreter = Interpreter(loadModelFile())

        // Find each EditText by ID
        editText1 = findViewById(R.id.editText1)
        editText2 = findViewById(R.id.editText2)
        editText3 = findViewById(R.id.editText3)
        editText4 = findViewById(R.id.editText4)
        editText5 = findViewById(R.id.editText5)
        editText6 = findViewById(R.id.editText6)
        editText7 = findViewById(R.id.editText7)
        editText8 = findViewById(R.id.editText8)
        editText9 = findViewById(R.id.editText9)

        val predictButton = findViewById<Button>(R.id.predictButton)
        val resultTextView = findViewById<TextView>(R.id.resultTextView)

        predictButton.setOnClickListener {
            // Collect values from all EditText fields
            val inputValues = listOf(
                editText1.text.toString(),
                editText2.text.toString(),
                editText3.text.toString(),
                editText4.text.toString(),
                editText5.text.toString(),
                editText6.text.toString(),
                editText7.text.toString(),
                editText8.text.toString(),
                editText9.text.toString()
            ).map { it.trim().toFloatOrNull() }

            // Check if all values are present and valid
            if (inputValues.all { it != null }) {
                // Prepare ByteBuffer for input
                val byteBuffer = ByteBuffer.allocateDirect(4 * 1 * 9).order(ByteOrder.nativeOrder())
                inputValues.forEach { byteBuffer.putFloat(it!!) }

                // Create TensorBuffer for input
                val inputFeature = TensorBuffer.createFixedSize(intArrayOf(1, 9), DataType.FLOAT32)
                inputFeature.loadBuffer(byteBuffer)

                // Create TensorBuffer for output
                val outputFeature = TensorBuffer.createFixedSize(intArrayOf(1, 9), DataType.FLOAT32)

                // Run inference
                interpreter.run(inputFeature.buffer, outputFeature.buffer.rewind())

                // Calculate reconstruction loss
                val reconstructionLoss = calculateReconstructionLoss(inputFeature.floatArray, outputFeature.floatArray)

                // Check against the threshold
                resultTextView.text = if (reconstructionLoss > THRESHOLD) {
                    "Anomaly Detected"
                } else {
                    "Normal"
                }
            } else {
                resultTextView.text = "Please enter valid numerical values in all fields."
            }
        }
    }

    private fun loadModelFile(): ByteBuffer {
        val assetManager = assets
        val fileDescriptor = assetManager.openFd("permission_vae_model.tflite")
        val inputStream = fileDescriptor.createInputStream()
        val fileChannel = inputStream.channel
        val startOffset = fileDescriptor.startOffset
        val length = fileDescriptor.length
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, length).order(ByteOrder.nativeOrder())
    }

    private fun calculateReconstructionLoss(original: FloatArray, reconstructed: FloatArray): Float {
        var mse = 0f
        for (i in original.indices) {
            val error = original[i] - reconstructed[i]
            mse += error * error
        }
        mse /= 140

        return mse
    }
}
